import balloons_logo from "../assets/works/projects/balloons-logo.jpg";
import balloons_shot_1 from "../assets/works/projects/balloons-shot-1.jpg";
import balloons_shot_2 from "../assets/works/projects/balloons-shot-2.jpg";
import balloons_shot_3 from "../assets/works/projects/balloons-shot-3.jpg";
import balloons_shot_4 from "../assets/works/projects/balloons-shot-4.jpg";
import balloons_shot_5 from "../assets/works/projects/balloons-shot-5.jpg";

import koosh_logo from "../assets/works/projects/koosh-logo.jpg";
import koosh_shot_1 from "../assets/works/projects/koosh-shot-1.jpg";
import koosh_shot_2 from "../assets/works/projects/koosh-shot-2.jpg";
import koosh_shot_3 from "../assets/works/projects/koosh-shot-3.jpg";
import koosh_shot_4 from "../assets/works/projects/koosh-shot-4.jpg";
import koosh_shot_5 from "../assets/works/projects/koosh-shot-5.jpg";

import urang_logo from "../assets/works/projects/urang-logo.jpg";
import urang_shot_1 from "../assets/works/projects/urang-shot-1.jpg";
import urang_shot_2 from "../assets/works/projects/urang-shot-2.jpg";
import urang_shot_3 from "../assets/works/projects/urang-shot-3.jpg";
import urang_shot_4 from "../assets/works/projects/urang-shot-4.jpg";

import security_logo from "../assets/works/projects/security-logo.jpg";
import security_shot_1 from "../assets/works/projects/security-shot-1.jpg";
import security_shot_2 from "../assets/works/projects/security-shot-2.jpg";
import security_shot_3 from "../assets/works/projects/security-shot-3.jpg";
import security_shot_4 from "../assets/works/projects/security-shot-4.jpg";
import security_shot_5 from "../assets/works/projects/security-shot-5.jpg";

import raf_logo from "../assets/works/projects/raf-logo.jpg";
import raf_shot_1 from "../assets/works/projects/raf-shot-1.jpg";
import raf_shot_2 from "../assets/works/projects/raf-shot-2.jpg";
import raf_shot_3 from "../assets/works/projects/raf-shot-3.jpg";
import raf_shot_4 from "../assets/works/projects/raf-shot-4.jpg";

import barg_logo from "../assets/works/projects/barg-logo.jpg";
import barg_shot_1 from "../assets/works/projects/barg-shot-1.jpg";
import barg_shot_2 from "../assets/works/projects/barg-shot-2.jpg";
import barg_shot_3 from "../assets/works/projects/barg-shot-3.jpg";
import barg_shot_4 from "../assets/works/projects/barg-shot-4.jpg";
import barg_shot_5 from "../assets/works/projects/barg-shot-5.jpg";

import axis_logo from "../assets/works/projects/axis-logo.jpg";
import axis_shot_1 from "../assets/works/projects/axis-shot-1.jpg";
import axis_shot_2 from "../assets/works/projects/axis-shot-2.jpg";
import axis_shot_3 from "../assets/works/projects/axis-shot-3.jpg";
import axis_shot_4 from "../assets/works/projects/axis-shot-4.jpg";

import choobkhat_logo from "../assets/works/projects/choobkhat-logo.jpg";
import choobkhat_shot_1 from "../assets/works/projects/choobkhat-shot-1.jpg";
import choobkhat_shot_2 from "../assets/works/projects/choobkhat-shot-2.jpg";
import choobkhat_shot_3 from "../assets/works/projects/choobkhat-shot-3.jpg";
import choobkhat_shot_4 from "../assets/works/projects/choobkhat-shot-4.jpg";
import choobkhat_shot_5 from "../assets/works/projects/choobkhat-shot-5.jpg";

import studiar_logo from "../assets/works/projects/studiar-logo.jpg";
import studiar_shot_1 from "../assets/works/projects/studiar-shot-1.jpg";
import studiar_shot_2 from "../assets/works/projects/studiar-shot-2.jpg";

import viriya_logo from "../assets/works/projects/viriya-logo.jpg";
import viriya_shot_1 from "../assets/works/projects/viriya-shot-1.jpg";
import viriya_shot_2 from "../assets/works/projects/viriya-shot-2.jpg";
import viriya_shot_3 from "../assets/works/projects/viriya-shot-3.jpg";
import viriya_shot_4 from "../assets/works/projects/viriya-shot-4.jpg";
import viriya_shot_5 from "../assets/works/projects/viriya-shot-5.jpg";

import mn76_logo from "../assets/works/projects/mn76-logo.jpg";
import mn76_shot_1 from "../assets/works/projects/mn76-shot-1.jpg";
import mn76_shot_2 from "../assets/works/projects/mn76-shot-2.jpg";
import mn76_shot_3 from "../assets/works/projects/mn76-shot-3.jpg";
import mn76_shot_4 from "../assets/works/projects/mn76-shot-4.jpg";
import mn76_shot_5 from "../assets/works/projects/mn76-shot-5.jpg";

import dorm_logo from "../assets/works/projects/dorm-logo.jpg";
import dorm_live from "../assets/works/projects/dorm-live.jpg";
import dorm_shot_1 from "../assets/works/projects/dorm-shot-1.jpg";
import dorm_shot_2 from "../assets/works/projects/dorm-shot-2.jpg";
import dorm_shot_3 from "../assets/works/projects/dorm-shot-3.jpg";

export default {
  balloons_logo,
  balloons_shot_1,
  balloons_shot_2,
  balloons_shot_3,
  balloons_shot_4,
  balloons_shot_5,
  koosh_logo,
  koosh_shot_1,
  koosh_shot_2,
  koosh_shot_3,
  koosh_shot_4,
  koosh_shot_5,
  urang_logo,
  urang_shot_1,
  urang_shot_2,
  urang_shot_3,
  urang_shot_4,
  security_logo,
  security_shot_1,
  security_shot_2,
  security_shot_3,
  security_shot_4,
  security_shot_5,
  raf_logo,
  raf_shot_1,
  raf_shot_2,
  raf_shot_3,
  raf_shot_4,
  barg_logo,
  barg_shot_1,
  barg_shot_2,
  barg_shot_3,
  barg_shot_4,
  barg_shot_5,
  axis_logo,
  axis_shot_1,
  axis_shot_2,
  axis_shot_3,
  axis_shot_4,
  choobkhat_logo,
  choobkhat_shot_1,
  choobkhat_shot_2,
  choobkhat_shot_3,
  choobkhat_shot_4,
  choobkhat_shot_5,
  studiar_logo,
  studiar_shot_1,
  studiar_shot_2,
  viriya_logo,
  viriya_shot_1,
  viriya_shot_2,
  viriya_shot_3,
  viriya_shot_4,
  viriya_shot_5,
  mn76_logo,
  mn76_shot_1,
  mn76_shot_2,
  mn76_shot_3,
  mn76_shot_4,
  mn76_shot_5,
  dorm_logo,
  dorm_live,
  dorm_shot_1,
  dorm_shot_2,
  dorm_shot_3,
};
