import unity_vid from '../assets/unity/unity_vid.mp4'

export default {
    unity_vid
};