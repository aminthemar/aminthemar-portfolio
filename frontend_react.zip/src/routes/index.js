export { default as HomePage } from './HomePage/HomePage'
export { default as WorksPage } from './WorksPage/WorksPage'
export { default as ProjectPage } from './ProjectPage/ProjectPage'